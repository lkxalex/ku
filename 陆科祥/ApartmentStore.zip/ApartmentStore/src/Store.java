import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Window;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class Store extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2L;
	private JPanel contentPane;
	private JTable table;
	private String name;
	private JComboBox comboBox = new JComboBox();
	private JComboBox comboBox_1 = new JComboBox();
	private JComboBox comboBox_2 = new JComboBox();
	private JComboBox comboBox_3 = new JComboBox();
	private JComboBox comboBox_4 = new JComboBox();
	/**


	/**
	 * Create the frame.
	 */
	public Store(String name) {
		this.name = name;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JLabel label = new JLabel("\u6B22\u8FCE\u8FDB\u5165\u5546\u5E97");
		label.setBounds(126, 10, 117, 15);
		panel.add(label);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 35, 212, 21);
		panel.add(scrollPane);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"\u7F16\u53F7", "\u540D\u79F0", "\u5355\u4EF7"
			}
		));
		scrollPane.setViewportView(table);
		
		
		
		
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"0", "1", "2", "3", "4", "5"}));
		comboBox.setBounds(241, 60, 54, 21);
		panel.add(comboBox);
		
		
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"0", "1", "2", "3", "4", "5"}));
		comboBox_1.setBounds(241, 80, 54, 21);
		panel.add(comboBox_1);
		
		
		comboBox_2.setModel(new DefaultComboBoxModel(new String[] {"0", "1", "2", "3", "4", "5"}));
		comboBox_2.setBounds(241, 100, 54, 21);
		panel.add(comboBox_2);
		
		
		comboBox_3.setModel(new DefaultComboBoxModel(new String[] {"0", "1", "2", "3", "4", "5"}));
		comboBox_3.setBounds(241, 122, 54, 21);
		panel.add(comboBox_3);
		
	
		comboBox_4.setModel(new DefaultComboBoxModel(new String[] {"0", "1", "2", "3", "4", "5"}));
		comboBox_4.setBounds(241, 142, 54, 21);
		panel.add(comboBox_4);
		
		JLabel label_1 = new JLabel("\u6211\u8981\u8D2D\u4E70");
		label_1.setBounds(241, 35, 54, 15);
		panel.add(label_1);
		
		JButton btnNewButton = new JButton("\u786E\u8BA4\u8D2D\u4E70");
		btnNewButton.addActionListener(new ActionListener() {
			private Object frame;

			public void actionPerformed(ActionEvent e) {
				Check m = new Check(comboBox.getSelectedItem(),comboBox_1.getSelectedItem(),comboBox_2.getSelectedItem(),comboBox_3.getSelectedItem(),comboBox_4.getSelectedItem());
				m.setVisible(true);
				
			  
			}
		});
		btnNewButton.setBounds(233, 201, 134, 40);
		panel.add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setText(name);
		lblNewLabel.setBounds(275, 10, 117, 15);
		panel.add(lblNewLabel);
		
		JButton button = new JButton("\u4FEE\u6539\u8D44\u6599");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Login n=new Login();
				n.setVisible(true);
				dispose();
			}
		});
		button.setBounds(321, 38, 93, 23);
		panel.add(button);
		
		JLabel lblNewLabel_1 = new JLabel("001");
		lblNewLabel_1.setBounds(0, 63, 54, 15);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("002");
		lblNewLabel_2.setBounds(0, 83, 54, 15);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("003");
		lblNewLabel_3.setBounds(0, 103, 54, 15);
		panel.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("004");
		lblNewLabel_4.setBounds(0, 125, 54, 15);
		panel.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("005");
		lblNewLabel_5.setBounds(0, 145, 54, 15);
		panel.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("\u77FF\u6CC9\u6C34");
		lblNewLabel_6.setBounds(74, 63, 54, 15);
		panel.add(lblNewLabel_6);
		
		JLabel lblNewLabel_7 = new JLabel("\u65B9\u4FBF\u9762");
		lblNewLabel_7.setBounds(74, 83, 54, 15);
		panel.add(lblNewLabel_7);
		
		JLabel lblNewLabel_8 = new JLabel("\u706B\u817F\u80A0");
		lblNewLabel_8.setBounds(74, 103, 54, 15);
		panel.add(lblNewLabel_8);
		
		JLabel lblNewLabel_9 = new JLabel("\u997C\u5E72");
		lblNewLabel_9.setBounds(74, 125, 54, 15);
		panel.add(lblNewLabel_9);
		
		JLabel lblNewLabel_10 = new JLabel("\u5DE7\u514B\u529B");
		lblNewLabel_10.setBounds(74, 145, 54, 15);
		panel.add(lblNewLabel_10);
		
		JLabel lblNewLabel_11 = new JLabel("1");
		lblNewLabel_11.setBounds(148, 63, 54, 15);
		panel.add(lblNewLabel_11);
		
		JLabel lblNewLabel_12 = new JLabel("3");
		lblNewLabel_12.setBounds(148, 83, 54, 15);
		panel.add(lblNewLabel_12);
		
		JLabel lblNewLabel_13 = new JLabel("2");
		lblNewLabel_13.setBounds(148, 103, 54, 15);
		panel.add(lblNewLabel_13);
		
		JLabel lblNewLabel_14 = new JLabel("3");
		lblNewLabel_14.setBounds(148, 125, 54, 15);
		panel.add(lblNewLabel_14);
		
		JLabel lblNewLabel_15 = new JLabel("2");
		lblNewLabel_15.setBounds(148, 145, 54, 15);
		panel.add(lblNewLabel_15);
		
		JLabel label_2 = new JLabel("\u4EB2\u7231\u7684\uFF1A");
		label_2.setBounds(222, 10, 54, 15);
		panel.add(label_2);
	}
}

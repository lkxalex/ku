import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.SwingConstants;


public class Check extends JFrame {

	private JPanel contentPane;
	
	/**
	 * Launch the application.
	 */


	/**
	 * Create the frame.
	 */
	public Check(Object a,Object b,Object c, Object d,Object e) {
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JLabel label = new JLabel("\u4F60\u672C\u6B21\u5171\u8BA1\u6D88\u8D39\uFF1A");
		label.setBounds(10, 10, 180, 15);
		panel.add(label);
		
		JLabel lblx = new JLabel("");
		lblx.setVerticalAlignment(SwingConstants.TOP);
		String [] s =  new String[6];
		for(int i=0;i<6;i++){
			s[i] = "";
		}
		
		int j= -1;
		
		if(Integer.parseInt(a.toString())>0){
			j = j+1;
			s[j] += "��Ȫˮx"+a+"="+1*Integer.parseInt(a.toString())+"Ԫ";
		}
		
		if(Integer.parseInt(b.toString())>0){
			j = j+1;
			s[j] += "������x"+b+"="+3*Integer.parseInt(b.toString())+"Ԫ";
		}
		
		if(Integer.parseInt(c.toString())>0){
			j = j+1;
			s[j] += "���ȳ�x"+c+"="+2*Integer.parseInt(c.toString())+"Ԫ";
		}
		
		if(Integer.parseInt(d.toString())>0){
			j = j+1;
			s[j] += "����x"+d+"="+3*Integer.parseInt(d.toString())+"Ԫ";
		}
		
		if(Integer.parseInt(e.toString())>0){
			j = j+1;
			s[j] += "�ɿ���x"+e+"="+2*Integer.parseInt(e.toString())+"Ԫ";
		}
		int sum;
		sum = 1*Integer.parseInt(a.toString())
				+ 3*Integer.parseInt(b.toString()) 
				+ 2*Integer.parseInt(c.toString())
				+ 3*Integer.parseInt(d.toString())
				+ 2*Integer.parseInt(e.toString()) ;
		j = j+1;
		s[j] = "�ܼ�"+sum+"Ԫ";
	
		lblx.setText( "<html>"+s[0]+"<br>"+s[1]+"<br>"+s[2]+"<br>"+s[3]+"<br>"+s[4]+"<br>"+s[5]+"</html>");
		lblx.setBounds(70, 49, 207, 122);
		panel.add(lblx);
		
		JButton btnNewButton = new JButton("\u786E\u8BA4\u8D2D\u4E70");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "�����ĵȴ��ͻ�Ա��ϵ��", "����ɹ�", JOptionPane.WARNING_MESSAGE);
			
				dispose();
			}
		});
		btnNewButton.setBounds(150, 181, 93, 23);
		panel.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("\u8FD4\u56DE\u91CD\u9009");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				dispose();
			}
		});
		btnNewButton_1.setBounds(287, 181, 93, 23);
		panel.add(btnNewButton_1);
	}
}

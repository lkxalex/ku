import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Window;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JScrollPane;

import java.awt.Color;

import javax.swing.SwingConstants;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JLabel;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.DefaultComboBoxModel;


public class Login extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u6B22\u8FCE\u4F7F\u7528\u516C\u5BD3\u5546\u5E97");
		lblNewLabel.setBounds(152, 0, 104, 28);
		panel.add(lblNewLabel);
		
		JLabel label = new JLabel("\u8BF7\u586B\u5199\u4E2A\u4EBA\u8D44\u6599");
		label.setBounds(152, 38, 95, 15);
		panel.add(label);
		
		JLabel label_1 = new JLabel("\u59D3\u540D");
		label_1.setBounds(152, 63, 54, 15);
		panel.add(label_1);
		
		JLabel label_2 = new JLabel("\u5B66\u53F7");
		label_2.setBounds(152, 115, 54, 15);
		panel.add(label_2);
		
		JLabel label_3 = new JLabel("\u516C\u5BD3\u697C");
		label_3.setBounds(152, 140, 54, 15);
		panel.add(label_3);
		
		JLabel label_4 = new JLabel("\u7535\u8BDD");
		label_4.setBounds(152, 165, 54, 15);
		panel.add(label_4);
		
		JLabel label_5 = new JLabel("\u6027\u522B");
		label_5.setBounds(152, 90, 54, 15);
		panel.add(label_5);
		
		JButton button = new JButton("\u5F00\u59CB\u8D2D\u7269");
		button.addActionListener(new ActionListener() {
			private Object frame;

			public void actionPerformed(ActionEvent e) {
				
				if(textField_2.getText().length() >=8 ){
					if(textField.getText() != null ){
						Store m = new Store(textField.getText().toString());
					    m.setVisible(true);
					    dispose();
					}
				}
				
				else {
					JOptionPane.showMessageDialog(null, "��������ȷ�������ֻ������Ա��ͻ�Ա��ʱ��ϵ��", "����", JOptionPane.WARNING_MESSAGE);
			
			    }
			}
		});
		button.setBounds(152, 206, 93, 23);
		panel.add(button);
		
		textField = new JTextField();
		
		textField.setBounds(190, 63, 104, 21);
		panel.add(textField);
		textField.setColumns(10);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"\u7537", "\u5973"}));
		comboBox.setBounds(200, 88, 38, 21);
		panel.add(comboBox);
		
		textField_1 = new JTextField();
		textField_1.setBounds(190, 112, 104, 21);
		panel.add(textField_1);
		textField_1.setColumns(10);
		
		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9"}));
		comboBox_1.setBounds(200, 140, 38, 21);
		panel.add(comboBox_1);
		
		textField_2 = new JTextField();
		textField_2.setBounds(190, 165, 104, 21);
		panel.add(textField_2);
		textField_2.setColumns(10);
		
		JLabel label_6 = new JLabel("(\u5FC5\u586B)");
		label_6.setBounds(152, 181, 54, 15);
		panel.add(label_6);
	}
}
